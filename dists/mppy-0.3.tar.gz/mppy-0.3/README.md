# mppy 
mppy - Implementação de Técnicas de Projeção Multidimensional em Python <p>
Trabalho de Conclusão de Curso - Thiago Henrique Ferreira <p>
Orientador: Tácito Trindade de Araújo Tiburtino Neves <p>

Técnicas Implementadas: <p>
Force Scheme -> OK <p>
LAMP -> OK <p>
LSP -> OK <p>
Pekalska -> OK, problem with stress <p>
PLMP -> almost OK, cholesky error (not matrix definite), using LU <p>
Sammon -> Not OK <p>

